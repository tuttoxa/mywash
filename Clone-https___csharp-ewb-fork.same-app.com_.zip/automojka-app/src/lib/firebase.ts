import { initializeApp } from 'firebase/app'
import { getFirestore } from 'firebase/firestore'
import { getAuth } from 'firebase/auth'
import { getStorage } from 'firebase/storage'
import { getAnalytics } from 'firebase/analytics'

// Firebase конфигурация
const firebaseConfig = {
  apiKey: "AIzaSyCNH---Cz9oSH-j8WgwBGoySI8tIOhts_w",
  authDomain: "wevb-72d77.firebaseapp.com",
  projectId: "wevb-72d77",
  storageBucket: "wevb-72d77.firebasestorage.app",
  messagingSenderId: "717472741705",
  appId: "1:717472741705:web:bb60059264ac8430db0298"
};

// Инициализация Firebase
const app = initializeApp(firebaseConfig)

// Получаем экземпляры сервисов
export const db = getFirestore(app)
export const auth = getAuth(app)
export const storage = getStorage(app)
export const analytics = typeof window !== 'undefined' ? getAnalytics(app) : null

export default app

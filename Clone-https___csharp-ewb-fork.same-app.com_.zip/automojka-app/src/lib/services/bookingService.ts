import { collection, addDoc, doc, getDoc, getDocs, updateDoc, deleteDoc, query, where } from 'firebase/firestore';
import { db } from '../firebase';
import { Booking, TimeSlot, DaySchedule } from '../types';

const BOOKINGS_COLLECTION = 'bookings';

// Получить все записи
export async function getAllBookings(): Promise<Booking[]> {
  try {
    const bookingsRef = collection(db, BOOKINGS_COLLECTION);
    const snapshot = await getDocs(bookingsRef);

    return snapshot.docs.map(doc => {
      const data = doc.data();
      return {
        id: doc.id,
        ...data,
        date: data.date?.toDate ? data.date.toDate() : new Date(data.date),
        createdAt: data.createdAt?.toDate ? data.createdAt.toDate() : new Date(),
        updatedAt: data.updatedAt?.toDate ? data.updatedAt.toDate() : new Date()
      } as Booking;
    });
  } catch (error) {
    console.error('Error getting bookings:', error);
    throw error;
  }
}

// Получить записи на определенную дату
export async function getBookingsByDate(date: Date): Promise<Booking[]> {
  try {
    const formattedDate = date.toISOString().split('T')[0];
    const bookingsRef = collection(db, BOOKINGS_COLLECTION);
    const snapshot = await getDocs(bookingsRef);

    return snapshot.docs
      .map(doc => {
        const data = doc.data();
        const booking = {
          id: doc.id,
          ...data,
          date: data.date?.toDate ? data.date.toDate() : new Date(data.date),
          createdAt: data.createdAt?.toDate ? data.createdAt.toDate() : new Date(),
          updatedAt: data.updatedAt?.toDate ? data.updatedAt.toDate() : new Date()
        } as Booking;
        return booking;
      })
      .filter(booking => {
        const bookingDate = booking.date.toISOString().split('T')[0];
        return bookingDate === formattedDate;
      });
  } catch (error) {
    console.error('Error getting bookings by date:', error);
    throw error;
  }
}

export interface Employee {
  id: string;
  firstName: string;
  lastName: string;
  middleName?: string;
  fullName?: string; // Вычисляемое поле
  birthDate: string;
  gender: 'male' | 'female';
  phone: string;
  email?: string;
  address?: string;
  position: 'washer' | 'manager' | 'tech' | 'cleaner';
  paymentType: 'percentage' | 'fixed';
  percentageRate?: number;
  salary?: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface Client {
  id: string;
  firstName: string;
  lastName: string;
  middleName?: string;
  fullName?: string; // Вычисляемое поле
  phone: string;
  email?: string;
  carInfo?: CarInfo[];
  visits: number; // Количество посещений (для скидки)
  discountPercent: number; // Процент скидки
  createdAt: Date;
  updatedAt: Date;
}

export interface CarInfo {
  id: string;
  brand: string;
  model: string;
  year?: number;
  color?: string;
  licensePlate: string; // Номер автомобиля
  clientId: string; // ID клиента-владельца
}

export interface Service {
  id: string;
  name: string;
  description?: string;
  price: number;
  duration: number; // Длительность в минутах
  category: 'basic' | 'premium' | 'additional';
  createdAt: Date;
  updatedAt: Date;
}

export interface Booking {
  id: string;
  clientId: string;
  clientName?: string; // Вычисляемое поле
  carId?: string;
  carInfo?: string; // Вычисляемое поле
  employeeId?: string;
  employeeName?: string; // Вычисляемое поле
  services: BookingService[];
  date: Date; // Дата записи
  time: string; // Время записи (HH:MM)
  duration: number; // Общая длительность в минутах
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  totalPrice: number; // Общая стоимость
  discountedPrice?: number; // Цена со скидкой
  discountPercent?: number; // Процент скидки
  notes?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface BookingService {
  serviceId: string;
  serviceName: string;
  price: number;
  duration: number;
}

export interface TimeSlot {
  time: string;
  available: boolean;
}

export interface DaySchedule {
  date: string; // YYYY-MM-DD
  timeSlots: TimeSlot[];
  isWeekend: boolean;
}

export interface WorkShift {
  id: string;
  employeeId: string;
  employeeName?: string;
  date: string; // YYYY-MM-DD
  startTime: string; // HH:MM
  endTime: string; // HH:MM
  status: 'planned' | 'completed' | 'cancelled';
  earnedAmount?: number; // Заработано за смену
  serviceCount?: number; // Количество оказанных услуг
  createdAt: Date;
  updatedAt: Date;
}

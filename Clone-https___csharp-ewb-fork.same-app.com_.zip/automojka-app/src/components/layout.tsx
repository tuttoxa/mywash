import { ReactNode } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { Home, Users, Settings, Menu, Calendar, Car } from 'lucide-react'
import { ThemeToggle } from './theme-toggle'
import { cn } from '@/lib/utils'

interface LayoutProps {
  children: ReactNode
}

function Layout({ children }: LayoutProps) {
  const location = useLocation()
  const currentPath = location.pathname

  const isActive = (path: string) => {
    if (path === '/') {
      return currentPath === '/'
    }
    return currentPath.startsWith(path)
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900">
      <header className="bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 shadow-sm sticky top-0 z-10">
        <div className="container mx-auto py-4 px-4 flex justify-between items-center">
          <div className="flex items-center">
            <button className="md:hidden mr-2 p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700">
              <Menu size={20} />
            </button>
            <Link to="/" className="text-xl font-bold text-slate-900 dark:text-white">
              АвтоМойка
            </Link>
          </div>
          <div className="flex items-center space-x-2">
            <ThemeToggle />
            <Link
              to="/settings"
              className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700"
            >
              <Settings size={20} />
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto flex">
        <aside className="hidden md:block w-64 p-4 bg-white dark:bg-slate-800 border-r border-slate-200 dark:border-slate-700 min-h-[calc(100vh-65px)]">
          <nav className="space-y-2">
            <Link
              to="/"
              className={cn(
                "flex items-center p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200",
                isActive('/') && "bg-slate-100 dark:bg-slate-700 text-blue-600 dark:text-blue-400 font-medium"
              )}
            >
              <Home size={20} className="mr-2" />
              <span>Главная</span>
            </Link>
            <Link
              to="/bookings"
              className={cn(
                "flex items-center p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200",
                isActive('/bookings') && "bg-slate-100 dark:bg-slate-700 text-blue-600 dark:text-blue-400 font-medium"
              )}
            >
              <Calendar size={20} className="mr-2" />
              <span>Записи</span>
            </Link>
            <Link
              to="/employees"
              className={cn(
                "flex items-center p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200",
                isActive('/employees') && "bg-slate-100 dark:bg-slate-700 text-blue-600 dark:text-blue-400 font-medium"
              )}
            >
              <Users size={20} className="mr-2" />
              <span>Сотрудники</span>
            </Link>
            <Link
              to="/clients"
              className={cn(
                "flex items-center p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200",
                isActive('/clients') && "bg-slate-100 dark:bg-slate-700 text-blue-600 dark:text-blue-400 font-medium"
              )}
            >
              <Car size={20} className="mr-2" />
              <span>Клиенты</span>
            </Link>
            <Link
              to="/settings"
              className={cn(
                "flex items-center p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200",
                isActive('/settings') && "bg-slate-100 dark:bg-slate-700 text-blue-600 dark:text-blue-400 font-medium"
              )}
            >
              <Settings size={20} className="mr-2" />
              <span>Настройки</span>
            </Link>
          </nav>
        </aside>

        <main className="flex-1 p-4 overflow-hidden">
          <div className="transition-container animate-fade-in">
            {children}
          </div>
        </main>
      </div>
    </div>
  )
}

export { Layout }

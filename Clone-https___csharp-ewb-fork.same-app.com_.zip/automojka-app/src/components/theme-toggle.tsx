import { useState, useEffect } from "react"
import { Moon, Sun, Monitor } from "lucide-react"

type Theme = "light" | "dark" | "system"

function ThemeToggle() {
  const [theme, setTheme] = useState<Theme>(() => {
    if (typeof window !== "undefined") {
      const storedTheme = localStorage.getItem("theme") as Theme
      return storedTheme || "system"
    }
    return "system"
  })

  useEffect(() => {
    const root = window.document.documentElement

    root.classList.remove("light", "dark")

    if (theme === "system") {
      const systemTheme = window.matchMedia("(prefers-color-scheme: dark)").matches
        ? "dark"
        : "light"

      root.classList.add(systemTheme)
      return
    }

    root.classList.add(theme)
    localStorage.setItem("theme", theme)
  }, [theme])

  return (
    <div className="relative">
      <button
        className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800"
        aria-label="Выбрать тему"
        onClick={() => {
          // Циклически переключаем темы
          const themes: Theme[] = ["light", "dark", "system"]
          const currentIndex = themes.indexOf(theme)
          const nextIndex = (currentIndex + 1) % themes.length
          setTheme(themes[nextIndex])
        }}
      >
        {theme === "light" && <Sun size={20} className="text-gray-500" />}
        {theme === "dark" && <Moon size={20} className="text-gray-500" />}
        {theme === "system" && <Monitor size={20} className="text-gray-500" />}
      </button>
    </div>
  )
}

export { ThemeToggle }

import { Routes, Route } from 'react-router-dom'
import { Layout } from './components/layout'
import { HomePage } from './pages/home'
import { SettingsPage } from './pages/settings'
import { EmployeesPage } from './pages/employees'
import { NewEmployeePage } from './pages/employees/new'
import { BookingsPage } from './pages/bookings'
import { NewBookingPage } from './pages/bookings/new'

function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/employees" element={<EmployeesPage />} />
        <Route path="/employees/new" element={<NewEmployeePage />} />
        <Route path="/bookings" element={<BookingsPage />} />
        <Route path="/bookings/new" element={<NewBookingPage />} />
        <Route path="/settings" element={<SettingsPage />} />
      </Routes>
    </Layout>
  )
}

export default App

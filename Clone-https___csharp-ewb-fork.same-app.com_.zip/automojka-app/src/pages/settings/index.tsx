import { useState } from 'react'
import { Sun, Moon, Palette, Save } from 'lucide-react'
import { cn } from '@/lib/utils'

type Theme = 'light' | 'dark' | 'system' | 'blue-gradient' | 'green-gradient' | 'sunset-gradient' | 'purple-gradient'

export function SettingsPage() {
  const [theme, setTheme] = useState<Theme>('system')
  const [enableAnimations, setEnableAnimations] = useState(true)
  const [confirmDeletion, setConfirmDeletion] = useState(true)

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault()
    // Здесь будет логика сохранения настроек в Firebase
    // Пока просто отображаем сообщение
    alert('Настройки сохранены')
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Настройки</h1>
      </div>

      <div className="bg-white dark:bg-slate-800 shadow-sm rounded-lg overflow-hidden border border-gray-200 dark:border-gray-700">
        <form onSubmit={handleSaveSettings}>
          <div className="p-6 space-y-8">
            <div className="space-y-4">
              <h2 className="text-lg font-medium text-gray-900 dark:text-white pb-2 border-b border-gray-200 dark:border-gray-700">
                Настройки темы и отображения
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                <button
                  type="button"
                  className={cn(
                    "flex items-center px-4 py-3 rounded-lg transition-all duration-200",
                    "bg-white text-gray-700 border border-gray-300",
                    "dark:bg-slate-700 dark:text-gray-200 dark:border-gray-600",
                    "hover:bg-gray-50 dark:hover:bg-slate-600",
                    theme === 'light' && "ring-2 ring-blue-500 dark:ring-blue-400"
                  )}
                  onClick={() => setTheme('light')}
                >
                  <Sun size={22} className="mr-2 text-yellow-500" />
                  <span className="font-medium">Светлая тема</span>
                </button>

                <button
                  type="button"
                  className={cn(
                    "flex items-center px-4 py-3 rounded-lg transition-all duration-200",
                    "bg-white text-gray-700 border border-gray-300",
                    "dark:bg-slate-700 dark:text-gray-200 dark:border-gray-600",
                    "hover:bg-gray-50 dark:hover:bg-slate-600",
                    theme === 'dark' && "ring-2 ring-blue-500 dark:ring-blue-400"
                  )}
                  onClick={() => setTheme('dark')}
                >
                  <Moon size={22} className="mr-2 text-blue-400" />
                  <span className="font-medium">Тёмная тема</span>
                </button>

                <button
                  type="button"
                  className={cn(
                    "flex items-center px-4 py-3 rounded-lg transition-all duration-200",
                    "bg-white text-gray-700 border border-gray-300",
                    "dark:bg-slate-700 dark:text-gray-200 dark:border-gray-600",
                    "hover:bg-gray-50 dark:hover:bg-slate-600",
                    theme === 'purple-gradient' && "ring-2 ring-blue-500 dark:ring-blue-400"
                  )}
                  onClick={() => setTheme('purple-gradient')}
                >
                  <Palette size={22} className="mr-2 text-purple-500" />
                  <span className="font-medium">Фиолетовый градиент</span>
                </button>

                <button
                  type="button"
                  className={cn(
                    "flex items-center px-4 py-3 rounded-lg transition-all duration-200",
                    "bg-white text-gray-700 border border-gray-300",
                    "dark:bg-slate-700 dark:text-gray-200 dark:border-gray-600",
                    "hover:bg-gray-50 dark:hover:bg-slate-600",
                    theme === 'blue-gradient' && "ring-2 ring-blue-500 dark:ring-blue-400"
                  )}
                  onClick={() => setTheme('blue-gradient')}
                >
                  <Palette size={22} className="mr-2 text-blue-500" />
                  <span className="font-medium">Синий градиент</span>
                </button>

                <button
                  type="button"
                  className={cn(
                    "flex items-center px-4 py-3 rounded-lg transition-all duration-200",
                    "bg-white text-gray-700 border border-gray-300",
                    "dark:bg-slate-700 dark:text-gray-200 dark:border-gray-600",
                    "hover:bg-gray-50 dark:hover:bg-slate-600",
                    theme === 'green-gradient' && "ring-2 ring-blue-500 dark:ring-blue-400"
                  )}
                  onClick={() => setTheme('green-gradient')}
                >
                  <Palette size={22} className="mr-2 text-green-500" />
                  <span className="font-medium">Зеленый градиент</span>
                </button>

                <button
                  type="button"
                  className={cn(
                    "flex items-center px-4 py-3 rounded-lg transition-all duration-200",
                    "bg-white text-gray-700 border border-gray-300",
                    "dark:bg-slate-700 dark:text-gray-200 dark:border-gray-600",
                    "hover:bg-gray-50 dark:hover:bg-slate-600",
                    theme === 'sunset-gradient' && "ring-2 ring-blue-500 dark:ring-blue-400"
                  )}
                  onClick={() => setTheme('sunset-gradient')}
                >
                  <Palette size={22} className="mr-2 text-orange-500" />
                  <span className="font-medium">Градиент заката</span>
                </button>

                <button
                  type="button"
                  className={cn(
                    "flex items-center px-4 py-3 rounded-lg transition-all duration-200",
                    theme === 'system'
                      ? "bg-blue-50 text-blue-700 ring-2 ring-blue-500 dark:bg-blue-900 dark:text-blue-100 dark:ring-blue-400"
                      : "bg-white text-gray-700 border border-gray-300 dark:bg-slate-700 dark:text-gray-200 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-slate-600"
                  )}
                  onClick={() => setTheme('system')}
                >
                  <span className="font-medium">Системная тема</span>
                </button>
              </div>

              <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center">
                  <input
                    id="enableAnimations"
                    type="checkbox"
                    className="h-4 w-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500"
                    checked={enableAnimations}
                    onChange={(e) => setEnableAnimations(e.target.checked)}
                  />
                  <label htmlFor="enableAnimations" className="ml-2 block text-sm text-gray-700 dark:text-gray-300">
                    Включить анимации интерфейса
                  </label>
                </div>

                <div className="flex items-center">
                  <input
                    id="confirmDeletion"
                    type="checkbox"
                    className="h-4 w-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500"
                    checked={confirmDeletion}
                    onChange={(e) => setConfirmDeletion(e.target.checked)}
                  />
                  <label htmlFor="confirmDeletion" className="ml-2 block text-sm text-gray-700 dark:text-gray-300">
                    Подтверждать удаление записей
                  </label>
                </div>
              </div>
            </div>
          </div>

          <div className="px-6 py-3 bg-gray-50 dark:bg-slate-700 text-right">
            <button
              type="submit"
              className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              <Save size={18} className="mr-2" />
              Сохранить настройки
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

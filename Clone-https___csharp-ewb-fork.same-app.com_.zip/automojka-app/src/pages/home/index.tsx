import { Link } from 'react-router-dom'
import { Users, Briefcase, Calendar, Award, ArrowUpRight } from 'lucide-react'

export function HomePage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold mb-4 md:mb-0 dark:text-white">Добро пожаловать!</h1>
      <p className="text-gray-600 dark:text-gray-300 mb-6">
        Электронная система учета услуг автомойки и управления персоналом
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
          <div className="flex items-center mb-4">
            <Users size={20} className="text-blue-500 mr-2" />
            <h2 className="text-lg font-medium">Сотрудники</h2>
          </div>
          <div className="text-3xl font-bold mb-2">0</div>
          <div className="text-sm text-gray-500 dark:text-gray-400">Всего в системе</div>
          <Link
            to="/employees"
            className="mt-4 text-blue-600 inline-flex items-center text-sm hover:underline"
          >
            Управление <ArrowUpRight size={14} className="ml-1" />
          </Link>
        </div>

        <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
          <div className="flex items-center mb-4">
            <Briefcase size={20} className="text-green-500 mr-2" />
            <h2 className="text-lg font-medium">Услуги</h2>
          </div>
          <div className="text-3xl font-bold mb-2">0</div>
          <div className="text-sm text-gray-500 dark:text-gray-400">Активных услуг</div>
          <Link
            to="/services"
            className="mt-4 text-green-600 inline-flex items-center text-sm hover:underline"
          >
            Управление <ArrowUpRight size={14} className="ml-1" />
          </Link>
        </div>

        <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
          <div className="flex items-center mb-4">
            <Calendar size={20} className="text-amber-500 mr-2" />
            <h2 className="text-lg font-medium">Записи</h2>
          </div>
          <div className="text-3xl font-bold mb-2">0</div>
          <div className="text-sm text-gray-500 dark:text-gray-400">Записей на сегодня</div>
          <Link
            to="/bookings"
            className="mt-4 text-amber-600 inline-flex items-center text-sm hover:underline"
          >
            Управление <ArrowUpRight size={14} className="ml-1" />
          </Link>
        </div>

        <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
          <div className="flex items-center mb-4">
            <Award size={20} className="text-purple-500 mr-2" />
            <h2 className="text-lg font-medium">Клиенты</h2>
          </div>
          <div className="text-3xl font-bold mb-2">0</div>
          <div className="text-sm text-gray-500 dark:text-gray-400">Постоянных клиентов</div>
          <Link
            to="/clients"
            className="mt-4 text-purple-600 inline-flex items-center text-sm hover:underline"
          >
            Управление <ArrowUpRight size={14} className="ml-1" />
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-white dark:bg-slate-800 shadow-sm rounded-lg overflow-hidden border border-gray-200 dark:border-gray-700 lg:col-span-2">
          <div className="p-4 border-b border-gray-200 dark:border-gray-700">
            <h3 className="text-lg font-medium">Журнал событий</h3>
            <p className="text-sm text-gray-500 dark:text-gray-400">История изменений, добавлений и удалений в системе</p>
          </div>
          <div className="p-4">
            <div className="text-center py-8 text-gray-500 dark:text-gray-400">
              Журнал пока пуст
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-800 shadow-sm rounded-lg overflow-hidden border border-gray-200 dark:border-gray-700">
          <div className="p-4 border-b border-gray-200 dark:border-gray-700">
            <h3 className="text-lg font-medium">Быстрые действия</h3>
          </div>
          <div className="p-4 space-y-2">
            <Link
              to="/employees"
              className="flex items-center p-3 bg-gray-50 dark:bg-slate-700 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-600 transition-colors"
            >
              <Users className="text-blue-500 mr-3" size={20} />
              <span className="font-medium">Просмотр списка сотрудников</span>
            </Link>
            <Link
              to="/employees/new"
              className="flex items-center p-3 bg-gray-50 dark:bg-slate-700 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-600 transition-colors"
            >
              <Users className="text-blue-500 mr-3" size={20} />
              <span className="font-medium">Добавить нового сотрудника</span>
            </Link>
            <Link
              to="/bookings/new"
              className="flex items-center p-3 bg-gray-50 dark:bg-slate-700 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-600 transition-colors"
            >
              <Calendar className="text-green-500 mr-3" size={20} />
              <span className="font-medium">Добавить новую запись</span>
            </Link>
            <div className="flex items-center p-3 bg-gray-50 dark:bg-slate-700 rounded-lg">
              <Calendar className="text-gray-400 dark:text-gray-500 mr-3" size={20} />
              <span className="font-medium text-gray-400 dark:text-gray-500">
                Формирование отчетов
                <span className="ml-2 text-xs bg-gray-200 dark:bg-gray-600 px-2 py-0.5 rounded-full">
                  Скоро
                </span>
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-800 p-6 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
        <h3 className="text-lg font-medium mb-4">О системе</h3>
        <div className="space-y-2">
          <p className="text-sm text-gray-700 dark:text-gray-300">
            АвтоМойка - система для цифрового учета работы автомойки,
            обслуживания клиентов, управления персоналом и расчёта зарплат.
          </p>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Версия 1.0
          </p>
        </div>
      </div>
    </div>
  )
}

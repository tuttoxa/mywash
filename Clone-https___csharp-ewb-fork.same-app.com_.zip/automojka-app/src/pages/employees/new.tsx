import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { ArrowLeft, Save, User, Phone, Calendar, Briefcase, AtSign, MapPin } from 'lucide-react'

export function NewEmployeePage() {
  const navigate = useNavigate()
  const [loading, setLoading] = useState(false)

  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    middleName: '',
    birthDate: '',
    gender: 'male',
    phone: '',
    email: '',
    address: '',
    position: '',
    salary: '',
    paymentType: 'percentage',
    percentageRate: '30',
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      // Здесь будет логика добавления сотрудника в Firebase
      console.log('Данные для добавления:', formData)

      // Имитация задержки сети
      await new Promise(resolve => setTimeout(resolve, 1000))

      // После успешного добавления переходим на страницу списка сотрудников
      navigate('/employees')
    } catch (error) {
      console.error('Ошибка при добавлении сотрудника:', error)
      alert('Произошла ошибка при добавлении сотрудника')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div className="flex items-center space-x-2">
          <Link to="/employees" className="p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors duration-200">
            <ArrowLeft size={18} className="text-slate-900 dark:text-white" />
          </Link>
          <h1 className="text-lg sm:text-xl font-bold text-gray-900 dark:text-white">
            Добавление нового сотрудника
          </h1>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
        <form onSubmit={handleSubmit}>
          <div className="p-6">
            <div className="space-y-6">
              <div>
                <h2 className="text-lg font-medium mb-4 pb-2 border-b border-gray-200 dark:border-gray-700">
                  Личные данные
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Фамилия <span className="text-red-500">*</span>
                    </label>
                    <div className="relative rounded-md shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <User className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        type="text"
                        id="lastName"
                        name="lastName"
                        required
                        value={formData.lastName}
                        onChange={handleChange}
                        className="block w-full pl-10 pr-3 py-2 sm:text-sm border border-gray-300 dark:border-gray-600 rounded-md dark:bg-slate-700 dark:text-white"
                        placeholder="Фамилия сотрудника"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Имя <span className="text-red-500">*</span>
                    </label>
                    <div className="relative rounded-md shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <User className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        type="text"
                        id="firstName"
                        name="firstName"
                        required
                        value={formData.firstName}
                        onChange={handleChange}
                        className="block w-full pl-10 pr-3 py-2 sm:text-sm border border-gray-300 dark:border-gray-600 rounded-md dark:bg-slate-700 dark:text-white"
                        placeholder="Имя сотрудника"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="middleName" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Отчество
                    </label>
                    <div className="relative rounded-md shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <User className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        type="text"
                        id="middleName"
                        name="middleName"
                        value={formData.middleName}
                        onChange={handleChange}
                        className="block w-full pl-10 pr-3 py-2 sm:text-sm border border-gray-300 dark:border-gray-600 rounded-md dark:bg-slate-700 dark:text-white"
                        placeholder="Отчество сотрудника (если есть)"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="birthDate" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Дата рождения <span className="text-red-500">*</span>
                    </label>
                    <div className="relative rounded-md shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Calendar className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        type="date"
                        id="birthDate"
                        name="birthDate"
                        required
                        value={formData.birthDate}
                        onChange={handleChange}
                        className="block w-full pl-10 pr-3 py-2 sm:text-sm border border-gray-300 dark:border-gray-600 rounded-md dark:bg-slate-700 dark:text-white"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="gender" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Пол <span className="text-red-500">*</span>
                    </label>
                    <div className="flex space-x-4">
                      <div className="flex items-center">
                        <input
                          id="gender-male"
                          name="gender"
                          type="radio"
                          value="male"
                          checked={formData.gender === 'male'}
                          onChange={handleChange}
                          className="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500"
                        />
                        <label htmlFor="gender-male" className="ml-2 block text-sm text-gray-700 dark:text-gray-300">
                          Мужской
                        </label>
                      </div>
                      <div className="flex items-center">
                        <input
                          id="gender-female"
                          name="gender"
                          type="radio"
                          value="female"
                          checked={formData.gender === 'female'}
                          onChange={handleChange}
                          className="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500"
                        />
                        <label htmlFor="gender-female" className="ml-2 block text-sm text-gray-700 dark:text-gray-300">
                          Женский
                        </label>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Телефон <span className="text-red-500">*</span>
                    </label>
                    <div className="relative rounded-md shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Phone className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        type="tel"
                        id="phone"
                        name="phone"
                        required
                        value={formData.phone}
                        onChange={handleChange}
                        className="block w-full pl-10 pr-3 py-2 sm:text-sm border border-gray-300 dark:border-gray-600 rounded-md dark:bg-slate-700 dark:text-white"
                        placeholder="+7 (XXX) XXX-XX-XX"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Email
                    </label>
                    <div className="relative rounded-md shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <AtSign className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        className="block w-full pl-10 pr-3 py-2 sm:text-sm border border-gray-300 dark:border-gray-600 rounded-md dark:bg-slate-700 dark:text-white"
                        placeholder="email@example.com"
                      />
                    </div>
                  </div>

                  <div className="space-y-2 md:col-span-2">
                    <label htmlFor="address" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Адрес
                    </label>
                    <div className="relative rounded-md shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <MapPin className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        type="text"
                        id="address"
                        name="address"
                        value={formData.address}
                        onChange={handleChange}
                        className="block w-full pl-10 pr-3 py-2 sm:text-sm border border-gray-300 dark:border-gray-600 rounded-md dark:bg-slate-700 dark:text-white"
                        placeholder="Полный адрес проживания"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h2 className="text-lg font-medium mb-4 pb-2 border-b border-gray-200 dark:border-gray-700">
                  Данные о работе
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label htmlFor="position" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Должность <span className="text-red-500">*</span>
                    </label>
                    <div className="relative rounded-md shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Briefcase className="h-5 w-5 text-gray-400" />
                      </div>
                      <select
                        id="position"
                        name="position"
                        required
                        value={formData.position}
                        onChange={handleChange}
                        className="block w-full pl-10 pr-3 py-2 sm:text-sm border border-gray-300 dark:border-gray-600 rounded-md dark:bg-slate-700 dark:text-white"
                      >
                        <option value="">Выберите должность</option>
                        <option value="washer">Мойщик</option>
                        <option value="manager">Администратор</option>
                        <option value="tech">Техник</option>
                        <option value="cleaner">Уборщик</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="paymentType" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Тип оплаты <span className="text-red-500">*</span>
                    </label>
                    <div className="flex space-x-4">
                      <div className="flex items-center">
                        <input
                          id="paymentType-percentage"
                          name="paymentType"
                          type="radio"
                          value="percentage"
                          checked={formData.paymentType === 'percentage'}
                          onChange={handleChange}
                          className="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500"
                        />
                        <label htmlFor="paymentType-percentage" className="ml-2 block text-sm text-gray-700 dark:text-gray-300">
                          Процент
                        </label>
                      </div>
                      <div className="flex items-center">
                        <input
                          id="paymentType-fixed"
                          name="paymentType"
                          type="radio"
                          value="fixed"
                          checked={formData.paymentType === 'fixed'}
                          onChange={handleChange}
                          className="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500"
                        />
                        <label htmlFor="paymentType-fixed" className="ml-2 block text-sm text-gray-700 dark:text-gray-300">
                          Фиксированная ставка
                        </label>
                      </div>
                    </div>
                  </div>

                  {formData.paymentType === 'percentage' ? (
                    <div className="space-y-2">
                      <label htmlFor="percentageRate" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                        Процентная ставка (%) <span className="text-red-500">*</span>
                      </label>
                      <div className="relative rounded-md shadow-sm">
                        <input
                          type="number"
                          id="percentageRate"
                          name="percentageRate"
                          min="1"
                          max="100"
                          required
                          value={formData.percentageRate}
                          onChange={handleChange}
                          className="block w-full px-3 py-2 sm:text-sm border border-gray-300 dark:border-gray-600 rounded-md dark:bg-slate-700 dark:text-white"
                          placeholder="30"
                        />
                        <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                          <span className="text-gray-500 sm:text-sm">%</span>
                        </div>
                      </div>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        Будет применяться к стоимости услуг
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <label htmlFor="salary" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                        Зарплата <span className="text-red-500">*</span>
                      </label>
                      <div className="relative rounded-md shadow-sm">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <span className="text-gray-500 sm:text-sm">₽</span>
                        </div>
                        <input
                          type="number"
                          id="salary"
                          name="salary"
                          min="0"
                          required={formData.paymentType === 'fixed'}
                          value={formData.salary}
                          onChange={handleChange}
                          className="block w-full pl-8 pr-3 py-2 sm:text-sm border border-gray-300 dark:border-gray-600 rounded-md dark:bg-slate-700 dark:text-white"
                          placeholder="30000"
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="px-6 py-3 bg-gray-50 dark:bg-slate-700 flex justify-end space-x-3">
            <Link
              to="/employees"
              className="py-2 px-4 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm text-sm font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-slate-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Отмена
            </Link>
            <button
              type="submit"
              disabled={loading}
              className="py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
            >
              {loading ? 'Сохранение...' : (
                <>
                  <Save size={18} className="mr-2" />
                  Сохранить
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

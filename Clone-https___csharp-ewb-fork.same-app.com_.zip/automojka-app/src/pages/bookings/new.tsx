import { useState, useEffect, useCallback } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { ArrowLeft, Save, Calendar, Clock, User, Car, BriefcaseBusiness, Check } from 'lucide-react'
import { format } from 'date-fns'
import { ru } from 'date-fns/locale'
import { getAvailableTimeSlots, addBooking } from '@/lib/services/bookingService'
import { TimeSlot, Service, BookingService } from '@/lib/types'
import { cn } from '@/lib/utils'

// Временные тестовые данные для услуг
const DUMMY_SERVICES: Service[] = [
  {
    id: '1',
    name: 'Мойка кузова',
    description: 'Стандартная мойка кузова автомобиля',
    price: 500,
    duration: 30,
    category: 'basic',
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    id: '2',
    name: 'Комплексная мойка',
    description: 'Мойка кузова + уборка салона',
    price: 1200,
    duration: 60,
    category: 'basic',
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    id: '3',
    name: 'Премиум комплекс',
    description: 'Комплексная мойка + чернение резины + обработка стекол',
    price: 2500,
    duration: 120,
    category: 'premium',
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    id: '4',
    name: 'Чистка салона',
    description: 'Полная чистка салона пылесосом',
    price: 800,
    duration: 45,
    category: 'additional',
    createdAt: new Date(),
    updatedAt: new Date()
  }
]

export function NewBookingPage() {
  const navigate = useNavigate()
  const [loading, setLoading] = useState(false)
  const [availableTimeSlots, setAvailableTimeSlots] = useState<TimeSlot[]>([])

  const [formData, setFormData] = useState({
    date: format(new Date(), 'yyyy-MM-dd'),
    time: '',
    clientName: '',
    clientPhone: '',
    carInfo: '',
    employeeId: '',
    services: [] as string[],
    notes: ''
  })

  const [services] = useState<Service[]>(DUMMY_SERVICES)
  const [selectedServices, setSelectedServices] = useState<BookingService[]>([])

  // Использование useCallback для предотвращения предупреждений ESLint
  const loadTimeSlots = useCallback(async () => {
    try {
      // Попробуем загрузить доступные слоты из Firebase
      try {
        const slots = await getAvailableTimeSlots(new Date(formData.date))
        setAvailableTimeSlots(slots)
      } catch (firebaseError) {
        console.error('Ошибка Firebase при загрузке слотов:', firebaseError)
        // В случае ошибки Firebase используем тестовые данные
        generateDummyTimeSlots()
      }
    } catch (error) {
      console.error('Общая ошибка при загрузке временных слотов:', error)
      // В случае любой ошибки загружаем тестовые слоты
      generateDummyTimeSlots()
    }
  }, [formData.date])

  useEffect(() => {
    loadTimeSlots()
  }, [loadTimeSlots])

  // Генерация тестовых слотов для предпросмотра
  const generateDummyTimeSlots = () => {
    const slots: TimeSlot[] = []
    const startHour = 8
    const endHour = 20

    for (let hour = startHour; hour < endHour; hour++) {
      for (let minute = 0; minute < 60; minute += 30) {
        slots.push({
          time: `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`,
          available: Math.random() > 0.3 // 70% вероятность, что слот доступен
        })
      }
    }

    setAvailableTimeSlots(slots)
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleTimeSelect = (time: string) => {
    setFormData(prev => ({ ...prev, time }))
  }

  const handleServiceToggle = (serviceId: string) => {
    // Если сервис уже выбран, удаляем его
    if (formData.services.includes(serviceId)) {
      setFormData(prev => ({
        ...prev,
        services: prev.services.filter(id => id !== serviceId)
      }))
      setSelectedServices(prev => prev.filter(s => s.serviceId !== serviceId))
    } else {
      // Иначе добавляем сервис
      const service = services.find(s => s.id === serviceId)
      if (service) {
        setFormData(prev => ({
          ...prev,
          services: [...prev.services, serviceId]
        }))

        setSelectedServices(prev => [
          ...prev,
          {
            serviceId: service.id,
            serviceName: service.name,
            price: service.price,
            duration: service.duration
          }
        ])
      }
    }
  }

  const calculateTotalPrice = () => {
    return selectedServices.reduce((total, service) => total + service.price, 0)
  }

  const calculateTotalDuration = () => {
    return selectedServices.reduce((total, service) => total + service.duration, 0)
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return format(date, 'dd MMMM yyyy', { locale: ru })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.time || selectedServices.length === 0) {
      alert('Пожалуйста, выберите время и хотя бы одну услугу')
      return
    }

    setLoading(true)

    try {
      // Подготавливаем данные для записи
      const bookingData = {
        clientId: 'temp-client-id', // В реальном приложении здесь будет ID из базы данных
        clientName: formData.clientName,
        carInfo: formData.carInfo,
        employeeId: formData.employeeId || undefined,
        services: selectedServices,
        date: new Date(formData.date),
        time: formData.time,
        duration: calculateTotalDuration(),
        status: 'pending' as const,
        totalPrice: calculateTotalPrice(),
        notes: formData.notes,
      }

      // Сохраняем запись в Firebase
      try {
        const bookingId = await addBooking(bookingData)
        console.log('Запись успешно создана с ID:', bookingId)

        setTimeout(() => {
          // Переходим на страницу со списком записей
          navigate('/bookings')
        }, 500)
      } catch (firebaseError) {
        console.error('Ошибка Firebase при создании записи:', firebaseError)
        alert('Ошибка при сохранении записи в базе данных. Попробуйте еще раз позже.')

        // Для демонстрации - переходим на страницу записей даже при ошибке Firebase
        setTimeout(() => {
          navigate('/bookings')
        }, 1000)
      }
    } catch (error) {
      console.error('Общая ошибка при создании записи:', error)
      alert('Произошла ошибка при создании записи')
    } finally {
      setLoading(false)
    }
  }

  // Здесь остальная часть компонента - UI
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div className="flex items-center space-x-2">
          <Link to="/bookings" className="p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors duration-200">
            <ArrowLeft size={18} className="text-slate-900 dark:text-white" />
          </Link>
          <h1 className="text-lg sm:text-xl font-bold text-gray-900 dark:text-white">
            Создание новой записи
          </h1>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
        <form onSubmit={handleSubmit}>
          <div className="p-6">
            <div className="space-y-6">
              {/* Выбор даты и времени */}
              <div>
                <h2 className="text-lg font-medium mb-4 pb-2 border-b border-gray-200 dark:border-gray-700">
                  Дата и время
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label htmlFor="date" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Дата записи <span className="text-red-500">*</span>
                    </label>
                    <div className="relative rounded-md shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Calendar className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        type="date"
                        id="date"
                        name="date"
                        required
                        value={formData.date}
                        onChange={handleChange}
                        className="block w-full pl-10 pr-3 py-2 sm:text-sm border border-gray-300 dark:border-gray-600 rounded-md dark:bg-slate-700 dark:text-white"
                      />
                    </div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {formData.date && formatDate(formData.date)}
                    </p>
                  </div>

                  <div className="space-y-2">
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Время <span className="text-red-500">*</span>
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {availableTimeSlots.map((slot) => (
                        <button
                          key={slot.time}
                          type="button"
                          disabled={!slot.available}
                          className={cn(
                            "py-2 px-3 text-sm rounded-md transition-colors",
                            slot.available
                              ? formData.time === slot.time
                                ? "bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-200 font-medium"
                                : "bg-white text-gray-700 border border-gray-300 hover:bg-gray-50 dark:bg-slate-700 dark:text-gray-200 dark:border-gray-600 dark:hover:bg-slate-600"
                              : "bg-gray-100 text-gray-400 cursor-not-allowed dark:bg-slate-800 dark:text-gray-500"
                          )}
                          onClick={() => slot.available && handleTimeSelect(slot.time)}
                        >
                          {slot.time}
                          {formData.time === slot.time && (
                            <Check size={16} className="ml-1 inline-block" />
                          )}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Клиент и автомобиль */}
              <div>
                <h2 className="text-lg font-medium mb-4 pb-2 border-b border-gray-200 dark:border-gray-700">
                  Информация о клиенте
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label htmlFor="clientName" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      ФИО клиента <span className="text-red-500">*</span>
                    </label>
                    <div className="relative rounded-md shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <User className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        type="text"
                        id="clientName"
                        name="clientName"
                        required
                        value={formData.clientName}
                        onChange={handleChange}
                        className="block w-full pl-10 pr-3 py-2 sm:text-sm border border-gray-300 dark:border-gray-600 rounded-md dark:bg-slate-700 dark:text-white"
                        placeholder="Иванов Иван Иванович"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="clientPhone" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Телефон <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="tel"
                      id="clientPhone"
                      name="clientPhone"
                      required
                      value={formData.clientPhone}
                      onChange={handleChange}
                      className="block w-full px-3 py-2 sm:text-sm border border-gray-300 dark:border-gray-600 rounded-md dark:bg-slate-700 dark:text-white"
                      placeholder="+7 (XXX) XXX-XX-XX"
                    />
                  </div>

                  <div className="space-y-2 md:col-span-2">
                    <label htmlFor="carInfo" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Информация об автомобиле <span className="text-red-500">*</span>
                    </label>
                    <div className="relative rounded-md shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Car className="h-5 w-5 text-gray-400" />
                      </div>
                      <input
                        type="text"
                        id="carInfo"
                        name="carInfo"
                        required
                        value={formData.carInfo}
                        onChange={handleChange}
                        className="block w-full pl-10 pr-3 py-2 sm:text-sm border border-gray-300 dark:border-gray-600 rounded-md dark:bg-slate-700 dark:text-white"
                        placeholder="Марка, модель, гос. номер"
                      />
                    </div>
                  </div>

                  <div className="space-y-2 md:col-span-2">
                    <label htmlFor="employeeId" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                      Сотрудник (опционально)
                    </label>
                    <div className="relative rounded-md shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <BriefcaseBusiness className="h-5 w-5 text-gray-400" />
                      </div>
                      <select
                        id="employeeId"
                        name="employeeId"
                        value={formData.employeeId}
                        onChange={handleChange}
                        className="block w-full pl-10 pr-3 py-2 sm:text-sm border border-gray-300 dark:border-gray-600 rounded-md dark:bg-slate-700 dark:text-white"
                      >
                        <option value="">Выберите сотрудника (опционально)</option>
                        <option value="employee1">Сотрудник 1</option>
                        <option value="employee2">Сотрудник 2</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>

              {/* Услуги */}
              <div>
                <h2 className="text-lg font-medium mb-4 pb-2 border-b border-gray-200 dark:border-gray-700">
                  Выбор услуг <span className="text-red-500">*</span>
                </h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {services.map((service) => (
                    <div
                      key={service.id}
                      className={cn(
                        "border rounded-lg p-4 cursor-pointer transition-all",
                        formData.services.includes(service.id)
                          ? "border-blue-500 bg-blue-50 dark:bg-blue-900/20 dark:border-blue-400"
                          : "border-gray-200 hover:border-gray-300 dark:border-gray-700 dark:hover:border-gray-600"
                      )}
                      onClick={() => handleServiceToggle(service.id)}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="text-lg font-medium text-gray-900 dark:text-white">{service.name}</h3>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{service.description}</p>
                          <div className="mt-2 flex items-center text-sm">
                            <Clock size={16} className="mr-1 text-gray-400" />
                            <span className="text-gray-600 dark:text-gray-300">{service.duration} мин.</span>
                          </div>
                        </div>
                        <div className="text-right">
                          <span className="text-lg font-bold text-gray-900 dark:text-white">{service.price} ₽</span>
                          {formData.services.includes(service.id) && (
                            <div className="mt-2">
                              <span className="inline-flex items-center justify-center px-2 py-1 text-xs font-medium leading-none text-blue-600 bg-blue-100 rounded-full dark:bg-blue-900 dark:text-blue-200">
                                Выбрано
                              </span>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {selectedServices.length > 0 && (
                  <div className="mt-6 bg-gray-50 dark:bg-slate-900 p-4 rounded-lg border border-gray-200 dark:border-gray-700">
                    <h3 className="text-lg font-medium mb-2">Выбранные услуги</h3>
                    <ul className="space-y-2">
                      {selectedServices.map((service) => (
                        <li key={service.serviceId} className="flex justify-between">
                          <div className="flex items-center">
                            <Check size={16} className="text-green-500 mr-2" />
                            <span>{service.serviceName}</span>
                            <span className="ml-2 text-sm text-gray-500 dark:text-gray-400">({service.duration} мин.)</span>
                          </div>
                          <span className="font-medium">{service.price} ₽</span>
                        </li>
                      ))}
                    </ul>
                    <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700 flex justify-between">
                      <div>
                        <p>Общая длительность: <span className="font-medium">{calculateTotalDuration()} мин.</span></p>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          (≈ {Math.floor(calculateTotalDuration() / 60)} ч. {calculateTotalDuration() % 60} мин.)
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm">Итого:</p>
                        <p className="text-xl font-bold text-gray-900 dark:text-white">{calculateTotalPrice()} ₽</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Дополнительные примечания */}
              <div>
                <h2 className="text-lg font-medium mb-4 pb-2 border-b border-gray-200 dark:border-gray-700">
                  Дополнительная информация
                </h2>
                <div className="space-y-2">
                  <label htmlFor="notes" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                    Примечания
                  </label>
                  <textarea
                    id="notes"
                    name="notes"
                    value={formData.notes}
                    onChange={handleChange}
                    rows={3}
                    className="block w-full px-3 py-2 sm:text-sm border border-gray-300 dark:border-gray-600 rounded-md dark:bg-slate-700 dark:text-white"
                    placeholder="Дополнительные пожелания или примечания..."
                  ></textarea>
                </div>
              </div>
            </div>
          </div>

          <div className="px-6 py-3 bg-gray-50 dark:bg-slate-700 flex justify-end space-x-3">
            <Link
              to="/bookings"
              className="py-2 px-4 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm text-sm font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-slate-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Отмена
            </Link>
            <button
              type="submit"
              disabled={loading || !formData.time || selectedServices.length === 0}
              className="py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
            >
              {loading ? 'Сохранение...' : (
                <>
                  <Save size={18} className="mr-2" />
                  Создать запись
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

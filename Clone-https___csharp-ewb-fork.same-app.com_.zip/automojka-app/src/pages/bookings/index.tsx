import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Calendar, Clock, User, Car, Search, Plus, RotateCw, Check, X, AlertCircle } from 'lucide-react'
import { format } from 'date-fns'
import { ru } from 'date-fns/locale'
import { Booking } from '@/lib/types'
import { getAllBookings } from '@/lib/services/bookingService'
import { cn } from '@/lib/utils'

const statusColors = {
  pending: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300',
  confirmed: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
  completed: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
  cancelled: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300',
}

const statusIcons = {
  pending: <AlertCircle size={16} className="mr-1" />,
  confirmed: <Check size={16} className="mr-1" />,
  completed: <Check size={16} className="mr-1" />,
  cancelled: <X size={16} className="mr-1" />,
}

const statusLabels = {
  pending: 'Ожидание',
  confirmed: 'Подтверждена',
  completed: 'Выполнена',
  cancelled: 'Отменена',
}

// Функция для получения временных данных для демонстрации
const getDemoBookings = (): Booking[] => {
  const today = new Date()
  const tomorrow = new Date()
  tomorrow.setDate(today.getDate() + 1)

  return [
    {
      id: '1',
      clientId: 'client1',
      clientName: 'Иванов Иван Иванович',
      carInfo: 'Toyota Camry, А123ВС777',
      employeeId: 'employee1',
      employeeName: 'Петров Петр',
      services: [
        { serviceId: '1', serviceName: 'Мойка кузова', price: 500, duration: 30 },
        { serviceId: '4', serviceName: 'Чистка салона', price: 800, duration: 45 }
      ],
      date: today,
      time: '10:00',
      duration: 75,
      status: 'confirmed',
      totalPrice: 1300,
      createdAt: new Date(),
      updatedAt: new Date()
    },
    {
      id: '2',
      clientId: 'client2',
      clientName: 'Смирнова Елена Владимировна',
      carInfo: 'BMW X5, В789ЕК777',
      employeeId: 'employee2',
      employeeName: 'Сидоров Алексей',
      services: [
        { serviceId: '3', serviceName: 'Премиум комплекс', price: 2500, duration: 120 }
      ],
      date: tomorrow,
      time: '14:30',
      duration: 120,
      status: 'pending',
      totalPrice: 2500,
      createdAt: new Date(),
      updatedAt: new Date()
    },
    {
      id: '3',
      clientId: 'client3',
      clientName: 'Козлов Дмитрий Анатольевич',
      carInfo: 'Mercedes-Benz E-class, C321НП77',
      services: [
        { serviceId: '2', serviceName: 'Комплексная мойка', price: 1200, duration: 60 }
      ],
      date: today,
      time: '16:00',
      duration: 60,
      status: 'completed',
      totalPrice: 1200,
      discountedPrice: 1080,
      discountPercent: 10,
      createdAt: new Date(),
      updatedAt: new Date()
    }
  ]
}

export function BookingsPage() {
  const [bookings, setBookings] = useState<Booking[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState('')
  const [filterDate, setFilterDate] = useState<string>('')
  const [filterStatus, setFilterStatus] = useState<string>('')

  useEffect(() => {
    loadBookings()
  }, [])

  const loadBookings = async () => {
    setLoading(true)
    try {
      // Пытаемся загрузить данные из Firebase
      try {
        const data = await getAllBookings()
        console.log('Данные получены из Firebase:', data)
        setBookings(data)
      } catch (firebaseError) {
        console.error('Ошибка Firebase при загрузке записей:', firebaseError)
        // В случае ошибки загружаем демо-данные
        const demoData = getDemoBookings()
        console.log('Загружены демо-данные:', demoData)
        setBookings(demoData)
      }
    } catch (error) {
      console.error('Общая ошибка при загрузке записей:', error)
      setBookings([])
    } finally {
      setLoading(false)
    }
  }

  const filteredBookings = bookings.filter(booking => {
    // Поиск по строке
    const searchMatch =
      booking.clientName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      booking.carInfo?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      booking.employeeName?.toLowerCase().includes(searchTerm.toLowerCase())

    // Фильтр по дате
    const dateMatch = !filterDate ||
      (booking.date && format(booking.date, 'yyyy-MM-dd') === filterDate)

    // Фильтр по статусу
    const statusMatch = !filterStatus || booking.status === filterStatus

    return searchMatch && dateMatch && statusMatch
  })

  const formatDateTime = (date: Date, time: string) => {
    return `${format(date, 'dd MMMM yyyy', { locale: ru })}, ${time}`
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6 flex flex-col md:flex-row justify-between items-start md:items-center">
        <h1 className="text-3xl font-bold mb-4 md:mb-0 dark:text-white">Записи на мойку</h1>
        <div className="flex flex-col md:flex-row space-y-3 md:space-y-0 md:space-x-4 w-full md:w-auto">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            <input
              type="text"
              placeholder="Поиск по клиенту, авто..."
              className="pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg w-full md:w-64 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-slate-700 dark:text-white"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex space-x-2">
            <Link
              to="/bookings/new"
              className="flex items-center bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Plus size={18} className="mr-2" />
              Создать запись
            </Link>
            <button
              className="flex items-center gap-2 rounded-lg transition-all duration-300 px-4 py-2 bg-slate-100 text-slate-700 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
              aria-label="Обновить список записей"
              onClick={loadBookings}
            >
              <RotateCw size={18} className="transition-transform duration-700" />
              Обновить
            </button>
          </div>
        </div>
      </div>

      <div className="mb-4 flex flex-wrap gap-3">
        <div className="relative">
          <input
            type="date"
            className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-slate-700 dark:text-white"
            value={filterDate}
            onChange={(e) => setFilterDate(e.target.value)}
          />
          {filterDate && (
            <button
              className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
              onClick={() => setFilterDate('')}
            >
              <X size={16} />
            </button>
          )}
        </div>

        <select
          className="px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-slate-700 dark:text-white"
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
        >
          <option value="">Все статусы</option>
          <option value="pending">Ожидание</option>
          <option value="confirmed">Подтверждена</option>
          <option value="completed">Выполнена</option>
          <option value="cancelled">Отменена</option>
        </select>
      </div>

      <div className="overflow-x-auto rounded-lg shadow-md">
        <table className="min-w-full bg-white dark:bg-slate-800 divide-y divide-gray-200 dark:divide-gray-700">
          <thead className="bg-slate-100 dark:bg-slate-700">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                <div className="flex items-center">
                  <Calendar size={16} className="mr-2" />
                  Дата и время
                </div>
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                <div className="flex items-center">
                  <User size={16} className="mr-2" />
                  Клиент
                </div>
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                <div className="flex items-center">
                  <Car size={16} className="mr-2" />
                  Автомобиль
                </div>
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                <div className="flex items-center">
                  <Clock size={16} className="mr-2" />
                  Продолжительность
                </div>
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                Сумма
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                Статус
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
            {loading ? (
              <tr>
                <td colSpan={6} className="px-6 py-4 text-center text-sm text-gray-500 dark:text-gray-400">
                  Загрузка...
                </td>
              </tr>
            ) : filteredBookings.length > 0 ? (
              filteredBookings.map((booking, index) => (
                <tr
                  key={booking.id}
                  className="hover:bg-slate-50 dark:hover:bg-slate-700 cursor-pointer transition-colors animate-table-row-in"
                  style={{ animationDelay: `${index * 0.05}s` }}
                  onClick={() => window.location.href = `/bookings/${booking.id}`}
                >
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                    {booking.date && booking.time && formatDateTime(booking.date, booking.time)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">
                    {booking.clientName || 'Нет данных'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                    {booking.carInfo || 'Нет данных'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                    {booking.duration} мин.
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                    {booking.discountedPrice ? (
                      <div>
                        <span className="line-through mr-2">{booking.totalPrice} ₽</span>
                        <span className="font-medium text-green-600 dark:text-green-400">{booking.discountedPrice} ₽</span>
                        <span className="ml-1 text-xs text-green-600 dark:text-green-400">(-{booking.discountPercent}%)</span>
                      </div>
                    ) : (
                      <span>{booking.totalPrice} ₽</span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <span className={cn(
                      "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium",
                      statusColors[booking.status as keyof typeof statusColors]
                    )}>
                      {statusIcons[booking.status as keyof typeof statusIcons]}
                      {statusLabels[booking.status as keyof typeof statusLabels]}
                    </span>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={6} className="px-6 py-4 text-center text-sm text-gray-500 dark:text-gray-400">
                  {searchTerm || filterDate || filterStatus
                    ? 'Записи не найдены по вашему запросу'
                    : 'Нет доступных записей'}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}
